
def lengthNested(arr):
    counter = 0
    for i in range(len(arr)):
        if i is int:
            counter += 1
        else:
            for j in range(len(arr)):
                counter += if j is int
    return counter